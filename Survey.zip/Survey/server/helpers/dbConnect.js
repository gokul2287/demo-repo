
const mongoose = require('mongoose');

module.exports = (function () {
  const MONGO_URI = "mongodb://localhost/testdb";
  mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
      console.log('Connected to mongoose')
    })
    .catch((err) => {
      console.error('can\'t connect to database - \n' + err)
    });
})();
